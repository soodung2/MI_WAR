var express = require('express');
var router = express.Router();

router.get('/timeB2', function (req, res, next) {
  var db = req.db;
  db.collection('out').find({})
  .toArray(function(err, docs) {
    if (err) {
      next(err);
      return;
    }
    res.render('timeB2', {list: docs});
  });
});

module.exports = router;
